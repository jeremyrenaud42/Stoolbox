Import-Module "$env:SystemDrive\_Tech\Applications\Source\Modules\Verification.psm1"
Import-Module "$env:SystemDrive\_Tech\Applications\Source\Modules\AppManagement.psm1"
#Vérification des status des package manager
function Get-NugetStatus
{
    $nugetExist = test-path $env:APPDATA\NuGet
    return $nugetExist
}
function Get-WingetStatus
{
    $wingetCurrentVersion = winget -v
    $nb = $wingetCurrentVersion.Substring(1)  # Remove the 'v' prefix
    $wingetnbVersion = [version]$nb  # Convert to version type
    return $wingetnbVersion
}

function Get-ChocoStatus
{
    $chocoExist = Test-AppPresence "$env:SystemDrive\ProgramData\chocolatey"
    return $chocoExist
}

function Get-GitStatus
{
    $url = 'https://github.com/jeremyrenaud42/Stoolbox'
    $test = Test-Url -url $url
    return $test
}
function Get-FtpStatus
{
    $url = 'https://ftp.alexchato9.com'
    $test = Test-Url -url $url
    return $test
}

#Installation des package manager
function Install-Choco
{
   $progressPreference = 'SilentlyContinue'
   $chocoExist = Test-AppPresence "$env:SystemDrive\ProgramData\chocolatey"
   if($chocoExist -eq $false)
   {
       Invoke-WebRequest https://chocolatey.org/install.ps1 -TimeoutSec 5 -UseBasicParsing | Invoke-Expression | Out-Null
       $env:Path += ";$env:SystemDrive\ProgramData\chocolatey" #permet de pouvoir installer les logiciels sans reload powershell
   }
}

function Install-Winget
{
   $progressPreference = 'SilentlyContinue'
   $wingetCurrentVersion = winget -v
   $nb = $wingetCurrentVersion.Substring(1)  # Remove the 'v' prefix
   $wingetnbVersion = [version]$nb  # Convert to version type
   if ($wingetnbVersion -le [version]'1.10') 
   {  
       $vclibsUWPVersin = (Get-AppxPackage Microsoft.VCLibs.140.00.UWPDesktop).version
       if($vclibsUWPVersin -lt '14.0.30704.0')
       {
            Get-RemoteFile "Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_x64__8wekyb3d8bbwe.Appx" 'https://raw.githubusercontent.com/jeremyrenaud42/Stoolbox/main/PackageManager/Winget/Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_x64__8wekyb3d8bbwe.Appx' "$env:SystemDrive\_Tech\Applications\Source"
            Add-AppxPackage -path "$env:SystemDrive\_Tech\Applications\Source\Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_x64__8wekyb3d8bbwe.Appx" -ForceApplicationShutdown
       }
       $VCLibsExist = (Get-AppxPackage Microsoft.VCLibs.140.00).name
       if($null -eq $VCLibsExist)
       {
           Add-AppxPackage https://aka.ms/Microsoft.VCLibs.x64.14.00.Desktop.appx
       }
       $UIXamlExist = (Get-AppxPackage Microsoft.UI.Xaml.2.8).name
       if($null -eq $UIXamlExist )
       {
           Get-RemoteFile "Microsoft.UI.Xaml.2.8.x64.appx" 'https://raw.githubusercontent.com/jeremyrenaud42/Stoolbox/main/PackageManager/Winget/Microsoft.UI.Xaml.2.8.x64.appx' "$env:SystemDrive\_Tech\Applications\Source"
           Add-AppxPackage -path "$env:SystemDrive\_Tech\Applications\Source\Microsoft.UI.Xaml.2.8.x64.appx" -ForceApplicationShutdown
       }
       Get-RemoteFile "winget.msixbundle" 'https://aka.ms/getwinget' "$env:SystemDrive\_Tech\Applications\Source"
       Add-AppxPackage -path "$env:SystemDrive\_Tech\Applications\Source\winget.msixbundle" -ForceApplicationShutdown
   }
}

#winget upgrade winget
#Invoke-WebRequest -Uri https://github.com/microsoft/microsoft-ui-xaml/releases/download/v2.8.6/Microsoft.UI.Xaml.2.8.x64.appx -OutFile Microsoft.UI.Xaml.2.8.x64.appx
#Add-AppxPackage Microsoft.UI.Xaml.2.8.x64.appx
#Invoke-WebRequest -Uri https://aka.ms/Microsoft.VCLibs.x64.14.00.Desktop.appx -OutFile Microsoft.VCLibs.x64.14.00.Desktop.appx
#Add-AppxPackage Microsoft.VCLibs.x64.14.00.Desktop.appx

#Add-AppxPackage 'https://aka.ms/getwinget'

function Install-Nuget
{
   get-packageprovider -Name Nuget -Force #verifie et install si false
   $nugetModuleExist = Test-AppPresence "$env:SystemDrive\Program Files\WindowsPowerShell\Modules\NuGet"
   if($nugetModuleExist -eq $false)
   {
       Install-Module -Name NuGet -Force #pour use avec PowerShell
   }
}

function Wait-PackageManagerInstall
{
    $PackageManagerMessagebox = [System.Windows.MessageBox]::Show("Winget/Choco va s'installer. Cliquer sur ok pour continuer",$messageBoxTitle,0,64)
}
