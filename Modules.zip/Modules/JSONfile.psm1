#Load le JSON file en object PowerShell
function Import-JsonFile($Path)
{
    $jsonObject = Get-Content -Raw $Path | ConvertFrom-Json
    # Permettre d'utiliser des variables dans le JSON
    foreach ($Key in $JsonObject.PSObject.Properties.Name) {
        foreach ($Prop in $JsonObject.$Key.PSObject.Properties.Name) {
            $JsonObject.$Key.$Prop = $ExecutionContext.InvokeCommand.ExpandString($JsonObject.$Key.$Prop)
        }
    }
    return $jsonObject
}
#$jsonObject = Import-JsonFile -Path "C:\Users\Proprio\Downloads\test.json"

# Sauvegarder les changements dans le JSON file
function Save-JsonFile($jsonObject,$Path) 
{
    $jsonObject | ConvertTo-Json | Set-Content -Path $Path -Encoding UTF8 -Force #On garde encoding utf8 car v5.1 de PowerShell
}
#Save-JsonFile -jsonObject $jsonObject -Path "C:\Users\Proprio\Downloads\test.json"

# Vérifie si une MainKey existe
function Test-MainKey($jsonObject, $MainKey)
{
    return $jsonObject.PSObject.Properties.Name -contains $MainKey
}
#Test-MainKey -jsonObject $jsonObject -MainKey "Chrome"

# Obtenir une value
function Get-JsonValue($jsonObject, $MainKey, $Key) 
{
    return $jsonObject.$MainKey.$Key
}
#Get-JsonValue -jsonObject $jsonObject -MainKey "Chrome" -Key "WingetName"

# Set une value
function Set-JsonValue($jsonObject, $MainKey, $Key, $Value)
{
    $jsonObject.$MainKey.$Key = $Value
    return $jsonObject
}
#Set-JsonValue -jsonObject $jsonObject -MainKey "Chrome" -Key "WingetName" -Value "Google.Chrome"

function Update-JsonFile($FilePath, $MainKey, $Key, $Value) 
{
    $jsonObject = Import-JsonFile -Path $FilePath
    $jsonObject = Set-JsonValue -jsonObject $jsonObject -MainKey $MainKey -Key $Key -Value $Value
    Save-JsonFile -jsonObject $jsonObject -Path $FilePath
}
#Update-JsonFile -FilePath "C:\Users\Proprio\Downloads\test.json" -MainKey "TestApp" -Key "WingetName" -Value "Test.App"