function Test-RegistryKey($KeyPath)
{
    return Test-Path $KeyPath
}

function Test-RegistryEntry($keyPath, $EntryName)
{
    $registryKeyExists = Test-RegistryKey $KeyPath    
    if ($registryKeyExists)
    {
        $props = (Get-ItemProperty -Path $KeyPath).PSObject.Properties.Name
        return $props -contains $EntryName
    }
    else 
    {
        return $false
    }
}

function Get-RegistryValue($KeyPath,$EntryName)
{
    if (Test-RegistryEntry $KeyPath $EntryName)
    {
       return (Get-ItemProperty -Path $KeyPath -Name $EntryName).$EntryName
    }
    else 
    {
        return $null
    }
}

function New-RegistryKey($KeyPath)
{
    $registryKeyExists = Test-RegistryKey $KeyPath    
    if ($registryKeyExists -eq $false)
    {
        New-Item -Path $KeyPath -Force
    }

    if (Test-RegistryKey $KeyPath) 
    {
        return $true
    }
    else 
    {
        return $false
    }
}   

function Set-RegistryValue($KeyPath,$EntryName,$Type,$Value) #Créer si ca existe pas
{  
    if (-not (Test-RegistryKey $KeyPath))
    {
        New-RegistryKey $KeyPath
    }
    Set-ItemProperty -Path $KeyPath -Name $EntryName -Type $Type -Value $Value
    
    $NewValue = Get-RegistryValue $KeyPath $EntryName
    if ($NewValue -eq $Value) 
    {
        return $true
    }
    else 
    {
        return $false
    }
}

function Remove-RegistryKey($KeyPath)
{
    if (Test-RegistryKey $KeyPath) 
    {
        Remove-Item -Path $KeyPath -Force -Recurse -ErrorAction Stop
    }

    if (Test-RegistryKey $KeyPath) 
    {
        return $false
    }
    else 
    {
        return $true
    }
}
function Remove-RegistryEntry($KeyPath,$EntryName)
{  
    if (Test-RegistryEntry $KeyPath $EntryName)
    {
        Remove-ItemProperty -Path $KeyPath -Name $EntryName -ErrorAction Stop
    }
    if (Test-RegistryEntry $KeyPath $EntryName) 
    {
        return $false
    }
    else 
    {
        return $true
    }
}